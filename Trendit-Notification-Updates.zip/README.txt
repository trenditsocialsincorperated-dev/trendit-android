TRENDIt NOTIFICATION UPDATE

This ZIP adds a second GitHub Actions workflow. It does not replace your existing
"Extract Trendit Project" workflow.

STEPS
1. Upload this ZIP to the repository root.
2. Run your existing "Extract Trendit Project" workflow. It will extract the new
   workflow file into .github/workflows and commit it.
3. After extraction succeeds, open Actions.
4. Select "Apply Trendit Notification Updates".
5. Select Run workflow and run it on the branch containing the workflow.
6. The new workflow applies guarded edits and commits the five changed source files.

WHAT IT CHANGES
- Creates post notifications for the author's existing followers.
- Creates an in-app and push notification when someone unfollows an account.
- Allows the Netlify social-push function to accept "post" and "unfollow".
- Waits for the push endpoint response and logs HTTP/backend failure details.
  This helps diagnose DM push failures rather than silently discarding the result.

IMPORTANT
- The workflow checks every expected source-code anchor and stops if the repository
  source differs. It will not commit partial edits if an anchor is missing or duplicated.
- Push delivery still requires a valid recipient FCM token and the server-side
  FIREBASE_SERVICE_ACCOUNT_JSON environment variable.
- This does not configure Netlify secrets, Firebase credentials, Android native
  notification permissions, or background call behavior.
- It targets the repository default branch source snapshot inspected on 2026-11-21.
