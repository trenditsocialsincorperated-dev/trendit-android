# Trendit notification fixes — update package

This package contains a patch for the current `main` branch of
`trenditsocialsincorperated-dev/trendit-android`.

## Included changes

1. Adds `post` and `unfollow` to the app notification type.
2. Sends a post notification to the author's followers after a post is saved.
   Followers are notified in batches of 20.
3. Sends an unfollow notification after the unfollow operation succeeds.
4. Allows the Netlify `social-push` function to deliver `post` and `unfollow`
   notifications and returns more useful delivery diagnostics.
5. Makes the client await the push endpoint response and log HTTP errors or
   `sent: false` reasons. This is particularly useful for diagnosing the
   existing DM notification path; the DM trigger already exists in `dmService`.

## Apply

The included file is a unified Git patch. Apply it from the repository root
against the same `main` version that was inspected:

```bash
git apply --check patches/trendit-notification-fixes.patch
git apply patches/trendit-notification-fixes.patch
```

Then run:

```bash
npm run lint
npm run build:web
```

Commit/push using your own GitHub workflow or upload the changed files yourself.
This package does not push anything to GitHub.

## Important notes

- This patch does not change Android native call handling or ringtone behavior.
  The confirmed call issue is a separate background-call/Android incoming-call
  UI problem and should be addressed after these notification changes are tested.
- The DM frontend trigger already exists. The patch improves visibility into
  whether the backend returns an HTTP error or `sent: false`; it does not pretend
  the DM root cause is fixed without observing the response.
- New-post fan-out is initiated by the publishing client and reads
  `users/{authorUid}/followers`. It is suitable as a first implementation, but
  a server-side Firestore trigger is the better long-term design for very large
  accounts or strict anti-spam guarantees.
- The push endpoint still requires the existing Firebase Admin service-account
  environment variable and valid recipient FCM tokens.
